<?php
get_header();
 
if ( have_posts() ) : 
    while ( have_posts() ) : the_post();
    echo "<div class=\"blog-preview\">";
    echo "<h3>";    
    the_title();
    echo "</h3>";
    echo "<h5>";
        the_author();
    echo "</h5>";
    the_excerpt();
    echo "</div>";
    endwhile;
else :
    _e( 'Sorry, no posts matched your criteria.', 'textdomain' );
endif;
 
get_sidebar();
get_footer();
?>