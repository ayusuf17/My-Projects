<?php
get_header();
 
if ( have_posts() ) : 
    while ( have_posts() ) : the_post();
        the_content();
    endwhile;
else :
    _e( 'Sorry, no posts matched your criteria.', 'textdomain' );
endif;
echo "<h3> The Latest Blogs </h3>";
echo "<div class=\"blog-front\">";
 $latest_blog_posts = new WP_Query( array( 'posts_per_page' => 3 ) );
 
 if ( $latest_blog_posts->have_posts() ) : while ( $latest_blog_posts->have_posts() ) : $latest_blog_posts->the_post();
     // Loop output goes here
     echo "<div class=\"blog-preview\">";
     echo "<h3>";    
     the_title();
     echo "</h3>";
     echo "<h5>";
         the_author();
     echo "</h5>";
     the_excerpt();
     echo "</div>";

 endwhile; 
 endif; 
 echo "</div>";

 echo"";
 ?>
 <?php while ( have_posts() ) : the_post(); ?>

			<h1><?php the_field('intro-title'); ?></h1>
            <p><?php the_field('intro_paragraph');?></p>

			<img src="<?php the_field('image'); ?>" />

		<?php endwhile; // end of the loop. ?>
<?php
 echo"";
get_sidebar();
get_footer();
?>
